# Vishnu Tilt Live Wallpaper (Android Studio source)

This is a starter Android live-wallpaper project. It uses the phone accelerometer to switch between six avatar-view panels:
- Neutral: center panel
- Tilt left/right: side panels
- Tilt in the opposite vertical direction: lower row

## Build and install
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Install the APK on your Android phone.
4. Long-press the home screen > **Wallpaper & style** > **Live wallpapers** > **Vishnu Tilt Wallpaper** > **Set wallpaper**.

## Notes
- This is source code, not a prebuilt APK.
- Sensor direction and sensitivity vary by phone. The thresholds in `TiltWallpaperService.java` can be adjusted.
- The six included images are crops from the generated concept sheet, so this is a functional prototype rather than six separately commissioned full-resolution artworks.
- Some launchers may limit live-wallpaper sensor updates to save battery.
