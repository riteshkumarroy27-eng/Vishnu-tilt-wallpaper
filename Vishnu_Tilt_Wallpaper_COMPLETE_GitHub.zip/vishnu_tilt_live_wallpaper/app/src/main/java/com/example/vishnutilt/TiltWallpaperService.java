package com.example.vishnutilt;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.graphics.*;
import android.hardware.*;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.IOException;

public class TiltWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new TiltEngine(); }

    private class TiltEngine extends Engine implements SensorEventListener {
        private final SensorManager sensors = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        private final Sensor accelerometer = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        private final Handler handler = new Handler(Looper.getMainLooper());
        private Bitmap[][] panels = new Bitmap[2][3];
        private int col = 1, row = 0;
        private boolean visible = false;
        private float smoothX = 0f, smoothY = 0f;

        TiltEngine() {
            for (int r=0; r<2; r++) for (int c=0; c<3; c++) {
                try { panels[r][c] = BitmapFactory.decodeStream(getAssets().open("view_"+r+"_"+c+".jpg")); }
                catch (IOException ignored) {}
            }
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible && accelerometer != null)
                sensors.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
            else sensors.unregisterListener(this);
            drawFrame();
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            sensors.unregisterListener(this);
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;
            // Smooth the sensor readings to avoid rapid flickering between panels.
            smoothX = smoothX * 0.78f + event.values[0] * 0.22f;
            smoothY = smoothY * 0.78f + event.values[1] * 0.22f;

            int nextCol = smoothX > 3.0f ? 0 : (smoothX < -3.0f ? 2 : 1);
            int nextRow = smoothY < -3.0f ? 1 : 0;
            if (nextCol != col || nextRow != row) {
                col = nextCol; row = nextRow;
                drawFrame();
            }
        }

        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                Bitmap bitmap = panels[row][col];
                if (bitmap == null) {
                    canvas.drawColor(Color.BLACK);
                    return;
                }
                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                float scale = Math.max((float)canvas.getWidth()/bitmap.getWidth(),
                                        (float)canvas.getHeight()/bitmap.getHeight());
                float dw = bitmap.getWidth()*scale, dh = bitmap.getHeight()*scale;
                RectF dst = new RectF((canvas.getWidth()-dw)/2f, (canvas.getHeight()-dh)/2f,
                                      (canvas.getWidth()+dw)/2f, (canvas.getHeight()+dh)/2f);
                canvas.drawBitmap(bitmap, null, dst, paint);
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
        }

        @Override public void onDestroy() {
            sensors.unregisterListener(this);
            for (int r=0; r<2; r++) for (int c=0; c<3; c++)
                if (panels[r][c] != null) panels[r][c].recycle();
            super.onDestroy();
        }
    }
}
